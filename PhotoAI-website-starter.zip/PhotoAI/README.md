# PhotoAI — website starter

A responsive dark-theme AI image-generation website with a Node.js backend.

## Important architecture

Google Sites is the public landing page, not the application server. It cannot run this Node.js backend or securely store an OpenAI API key. Deploy this project to a web host that supports Node.js, then embed the deployed app URL in Google Sites. The app serves its own frontend and `/api/generate` endpoint from the same origin.

## Run locally

Requirements: Node.js LTS and an OpenAI API key with image-generation access.

1. Open a terminal in `server/`.
2. Install packages: `npm install`
3. Copy `.env.example` to `.env`.
4. Put your secret key in `.env`. Never publish `.env`, commit it, or put the key in browser code.
5. Start the server: `npm start`
6. Open `http://localhost:3000`.

## Deploy

Deploy the repository/project to a Node.js hosting provider. Set the start command to `npm start` and configure these environment variables in the host dashboard:

- `OPENAI_API_KEY` = your secret API key
- `OPENAI_IMAGE_MODEL` = `gpt-image-2.5-flare` (or another image model enabled for your account)

The host must serve the project root so that `server/server.js` can find the `public/` folder. If the host requires a root directory, use the project root, not `server/`.

Free hosting plans and their availability/limits change. Check the provider's current plan, sleeping/idle behavior, bandwidth limits, and whether it supports persistent Node.js web services before choosing one.

## Add to Google Sites

1. Create a Google Site at https://sites.google.com/new.
2. Add your title, logo, and introductory text.
3. Choose Insert → Embed → By URL.
4. Paste the deployed PhotoAI app's HTTPS URL.
5. Resize the embed section to a wide, tall layout, then preview desktop and mobile.
6. Publish the Google Site.

If the embed is blocked by the hosting provider's frame/security policy, use the Google Site as a landing page with a prominent button linking to the deployed PhotoAI app in a new tab.

## Before sharing publicly

Add authentication or rate limiting, usage limits, abuse prevention, and a privacy notice. This starter does not include user accounts, cloud image history, payments, or production-grade abuse controls. Image generation can incur API charges.
